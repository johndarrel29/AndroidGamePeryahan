package com.example.perya;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
