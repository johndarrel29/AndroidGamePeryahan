package com.example.perya;

public class ViewPagerItem {

    int imageID;

    public ViewPagerItem(int imageID) {
        this.imageID = imageID;
    }
}
