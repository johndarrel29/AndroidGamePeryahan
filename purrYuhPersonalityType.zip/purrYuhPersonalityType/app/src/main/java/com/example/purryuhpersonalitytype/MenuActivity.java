package com.example.purryuhpersonalitytype;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private Button startGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        startGame = (Button) findViewById(R.id.enter);
        startGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFirstPageActivity();
            }
        });

    }

    public void openFirstPageActivity(){
        Intent intent = new Intent(this, FirstPageActivity.class);
        startActivity(intent);
    }
}
