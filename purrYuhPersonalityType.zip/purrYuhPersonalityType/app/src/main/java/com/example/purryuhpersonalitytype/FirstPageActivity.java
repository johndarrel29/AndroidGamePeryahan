package com.example.purryuhpersonalitytype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstPageActivity extends AppCompatActivity {

    private MediaPlayer player;

    private Button startbtn, backbtn, mutebtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);

        startbtn = (Button) findViewById(R.id.startbutton);
        startbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openQuestionsActivity();}
        });

        backbtn = (Button) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                openMenuActivity();
            }
        });

        // Initialize MediaPlayer
        player = MediaPlayer.create(this, R.raw.bgmusic);

        // Start playing audio automatically when the app runs
        player.start();

        // Initialize the toggle button

        mutebtn = (Button) findViewById(R.id.mutebtn);
        mutebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                muteAudio();
            }
        });

    }

    public void muteAudio(){
        if (player.isPlaying()) {
            // If audio is playing, pause it and update button text
            player.pause();
            mutebtn.setText("Unmute Audio");
        } else {
            // If audio is paused, start it and update button text
            player.start();
            mutebtn.setText("Mute Audio");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release the MediaPlayer when the activity is destroyed
        if (player != null) {
            player.release();
            player = null;
        }
    }
//    public void openMenuActivity(){
//        Intent intent = new Intent(this, MenuActivity.class); >> menu ni thea dito
//        startActivity(intent);
//    }
    public void openQuestionsActivity(){
        Intent intent = new Intent(this, QuestionsActivity.class);
        startActivity(intent);
    }

}