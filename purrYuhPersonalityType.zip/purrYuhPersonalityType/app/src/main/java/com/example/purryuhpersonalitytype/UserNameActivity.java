package com.example.purryuhpersonalitytype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class UserNameActivity extends AppCompatActivity {

    private MediaPlayer player;
    private Button doneName, mutebtnUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_typename);

        doneName = findViewById(R.id.doneName);
        doneName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openResultsActivity();
            }
        });

        mutebtnUser = findViewById(R.id.mutebtnpt2);
        mutebtnUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                muteAudio2(); // Change to muteAudio2() as defined below
            }
        });
    }

    public void muteAudio2() {
        if (player == null) {
            // Initialize the MediaPlayer object if it's not already initialized
            player = MediaPlayer.create(this, R.raw.bgmusic);
        }

        if (player.isPlaying()) {
            // If audio is playing, pause it and update button text
            player.pause();
            mutebtnUser.setText("Unmute Audio");
        } else {
            // If audio is paused, start it and update button text
            player.start();
            mutebtnUser.setText("Mute Audio");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release the MediaPlayer when the activity is destroyed
        if (player != null) {
            player.release();
            player = null;
        }
    }

    public void openResultsActivity(){
        Intent intent = new Intent(this, ResultsActivity.class);
        startActivity(intent);
    }
}
